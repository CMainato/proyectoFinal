# Ionic 4 Music App starter

![](https://github.com/seagomezar/Ionic4-Music-Starter/blob/master/src/assets/img/logo.png =150x)

[![Build Status](https://travis-ci.org/seagomezar/Ionic4-Music-Starter.svg?branch=master)](https://travis-ci.org/seagomezar/Ionic4-Music-Starter)
![](https://img.shields.io/github/stars/seagomezar/Ionic4-Music-Starter)
![](https://img.shields.io/github/forks/seagomezar/Ionic4-Music-Starter)
![](https://img.shields.io/github/tag/seagomezar/Ionic4-Music-Starter)
![](https://img.shields.io/github/release/seagomezar/Ionic4-Music-Starter)
![](https://img.shields.io/github/issues/seagomezar/Ionic4-Music-Starter)

[TOCM]

[TOC]
