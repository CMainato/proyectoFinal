export const environment = {
  production: true,
  mapsApiKey: "AIzaSyC4oqAm-faNI6Y3vkNJioDXwOtAwWn3g4I"
};
